const App = () => {
  return (
    <div>
      Default App
    </div>
  );
};

export default App;