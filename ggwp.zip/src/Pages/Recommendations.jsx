
const Recommendations = () => {
    return (
        <div>
            
        </div>
    );
};

export default Recommendations;