import { Link } from 'react-router-dom';
import allCourses from '../../public/json/allCourses.json';

const Home = () => {
    return (
        <div>
            <div
                className="hero h-[500px]"
                style={{
                    backgroundImage: "url(https://img.daisyui.com/images/stock/photo-1507358522600-9f71e620c44e.webp)",
                }}>
                <div className="hero-overlay bg-opacity-90"></div>
                <div className="hero-content text-neutral-content text-center">
                    <div className="max-w-md">
                        <h1 className="mb-5 text-5xl font-bold">Hello there</h1>
                        <p className="mb-5">
                            Learn skills by leveraging your prior experience and assessing progress. Continuously evaluate through self-assessment, measurable goals, and external feedback to identify gaps, build on strengths, and achieve mastery efficiently.
                        </p>
                        <Link><button className="btn btn-primary">Get Recommendation</button></Link>
                        <div className='flex font-bold gap-3 justify-center mt-3'>
                            <Link to={'/'} className='hover:underline hover:text-lg'>Home</Link>
                            <Link to={'/evaluate'} className='hover:underline hover:text-lg'>Evaluation</Link>
                            <Link to={'/recommendations'} className='hover:underline hover:text-lg'>Recommendation</Link>
                        </div>
                    </div>
                </div>
            </div>
            
            {/* all courses */}
            <div>
                <div className="container mx-auto p-4">
                    <h1 className="text-3xl font-bold text-center mb-6">Web Development Courses</h1>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        {allCourses.map((course) => (
                            <div key={course.course_id} className="bg-white shadow-lg rounded-lg p-4 hover:shadow-2xl transition-shadow duration-300">
                                <h2 className="text-xl font-semibold mb-2">{course.Title}</h2>
                                <p className="text-gray-600 mb-4">
                                    <strong>Likes:</strong> {course.Like} <br />
                                    <strong>Views:</strong> {course.Views}
                                </p>
                                <a
                                    href={course.Link}
                                    className="block text-center text-white bg-blue-600 hover:bg-blue-700 py-2 px-4 rounded bottom-0"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    Watch Course
                                </a>

                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Home;