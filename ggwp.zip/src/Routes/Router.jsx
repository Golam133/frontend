
import {
    createBrowserRouter
} from "react-router-dom";
import Main from "../Layout/Main";
import Home from "../Pages/Home";
import Evaluation from "../Pages/Evaluation";
import Recommendations from "../Pages/Recommendations";
import op from "../Pages/op";

export const router = createBrowserRouter([
    {
        path: "/",
        element: <Main></Main>,
        children: [
            {
                path: "/",
                element: <Home></Home>,
            },
            {
                path: "/evaluate",
                element: <Evaluation></Evaluation>,
            },
            {
                path: "/recommendations",
                element: <Recommendations></Recommendations>,
            },
            {
                path: "/op",
                element: <op></op>,
            },

        ]
    },
]);